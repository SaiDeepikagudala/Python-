# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 12:42:06 2021

@author: SRINIVAS
"""

def reversalofstring():
    string = input("")
    rev = ''
    index = len(string)
    while index > 0 :
        rev = rev + string[index-1]
        index = index -1
    print(rev)
   
reversalofstring()
