# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:02:25 2021

@author: SRINIVAS
"""

import re
def correct(input_string):
    '''removing of extra space occurances'''
    corrected_string = re.sub('\\ +',' ',input_string)
    corrected_string = re.sub('\\.','. ',corrected_string)
    print(corrected_string)
INPUT_STRING = "This   is  very funny  and    cool.Indeed!"
'''calling function'''
correct(INPUT_STRING)
