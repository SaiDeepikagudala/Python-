# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 11:15:18 2021

@author: SRINIVAS
"""

def elementwise_greater_than(mylist, threshold):
    """Return a list with the same length as mylist, where the value at index i is 
    True if L[i] is greater than threshold, and False otherwise.
        >>> elementwise_greater_than([1, 2, 3, 4], 2)
    [False, False, True, True]
    """
    for i in mylist:
        if i>threshold :
            print("True")
        else :
            print("False")
mylist = [1,2,3,4]
elementwise_greater_than(mylist, 2)
