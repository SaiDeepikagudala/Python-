# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:17:38 2021

@author: SRINIVAS
"""

from itertools import permutations
def allPermutations(str):
    permList = permutations(str)
    for perm in list(permList):
        print (''.join(perm))
str = 'BCE'
print("All the permutations of the string", str,"are: ")
allPermutations(str)
