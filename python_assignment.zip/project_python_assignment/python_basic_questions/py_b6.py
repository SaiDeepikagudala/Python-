# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 11:40:51 2021

@author: SRINIVAS
"""

def anagram(word, list1):
    for word1 in list1:
        if(sorted(word1) == sorted(word)):
            print(word1)
    
word = 'pen'
list1 = ['huk','jke','epn','npe']    
anagram(word,list1)  
