# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 11:23:44 2021

@author: SRINIVAS
"""

def length():
    #in_put = input(" ")
    in_put = [1,2,3,4]
    count = 0
    for i in in_put:
        count+=1
    print(count)
length()
