# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 12:24:23 2021

@author: SRINIVAS
"""

def totalsum(list1):
    s = 0
    for i in list1:
        s = s + i
    print(s)
def multiplication(list1):
    s = 1
    for i in list1:
        s = s * i
    print(s)

list1 = [3,4,5,7]
totalsum(list1)
multiplication(list1)