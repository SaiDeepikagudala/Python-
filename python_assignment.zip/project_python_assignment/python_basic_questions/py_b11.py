# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 21:59:33 2021

@author: SRINIVAS
"""

def is_palindrome():
    string = input("")
    rev = ''
    index = len(string)
    while index > 0 :
        rev = rev + string[index-1]
        index = index -1
    if rev == string:
        print("palindrome")
    else:
        print("not a palindrome")
is_palindrome()