# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 10:17:16 2021

@author: SRINIVAS
"""

def max(a,b):
    if a>b:
        return a
    return b
a=10
b=23
res = max(a,b)
print(res)
