# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:08:07 2021

@author: SRINIVAS
"""

def sing_99_bottles():
    '''generating all the verses of the song'''
    for i in range(99, 0, -1):
        print ("%d bottles of beer on the wall, %d bottles of beer.\n" \
              "Take one down, pass it around, %d bottles of beer on the wall." % (i, i, i - 1))
if __name__ == "__main__":
    sing_99_bottles()
