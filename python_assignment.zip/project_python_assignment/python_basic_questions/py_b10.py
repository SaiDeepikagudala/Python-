# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:14:30 2021

@author: SRINIVAS
"""

def digital_root(num):
    '''function for finding digital root of a number'''
    if num == "0":
        return 0
    ans = 0
    for i in range (0, len(num)):
        ans = (ans + int(num[i])) % 9
    if ans == 0:
        return 9
    else:
        return ans % 9
NUM = "459024455663"
#NUM=input()
print (digital_root(NUM))