# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 12:18:41 2021

@author: SRINIVAS
"""

def checking(in_put):
    l1 = ['a','e','i','o','u']
    if in_put in l1:
        return True
    return False
in_put = input(" ")    
res = checking(in_put)
print(res)
