# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 10:35:13 2021

@author: SRINIVAS
"""

def isogram(string):
    st = string.lower()
    let_list =[]
    for letter in st:
        if letter.isalpha():
            if letter in let_list:
                return False
            let_list.append(letter)
    return True
string = input(" enter string for checking isogram: ")
res = isogram(string)
print(res)
    