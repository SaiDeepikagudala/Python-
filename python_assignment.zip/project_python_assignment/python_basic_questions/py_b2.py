# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 10:29:02 2021

@author: SRINIVAS
"""

def perfectNumber():
    num = int(input(" "))
    sum = 0
    for i in range(1,num):
        if num % i == 0:
            sum = sum + i
    if sum == num :
        print(f'{num} is a perfect number')
    else :
        print(f'{num} is not a perfect number')
perfectNumber()