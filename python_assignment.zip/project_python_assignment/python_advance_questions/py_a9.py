# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:21:08 2021

@author: SRINIVAS
"""
def freq(string):
    '''frequency of unique words'''
    string = STRING.split()
    str1 = []
    for i in string:
        if i not in str1:
            str1.append(i)
    for i in range(0, len(str1)):
        print('Frequency of', str1[i], '---', string.count(str1[i]))
STRING = 'aricent is part of altran and altran is part of capgemini'
#str=input(" ")
freq(STRING)
				 