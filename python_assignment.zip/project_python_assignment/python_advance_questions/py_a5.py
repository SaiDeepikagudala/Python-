# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:21:08 2021

@author: SRINIVAS
"""
def find_longest_word(words_list):
    '''finding length of the longest one.'''
    word_len = []
    for n_value in words_list:
        word_len.append((len(n_value), n_value))
    word_len.sort()
    return word_len[-1][0], word_len[-1][1]
result = find_longest_word(["testing", "python", "shell script","selenium"])
print(f'Longest word: {result[1]}  \nLength of the longest word: {result[0]}')
