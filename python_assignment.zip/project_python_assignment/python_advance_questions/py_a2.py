# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:21:08 2021

@author: SRINIVAS
"""
def is_member():
    '''in operator'''
    a_list=('this','is','second','question','sai')
    x_value='sai'
    if x_value in a_list:
        print('True')
    else:
        print('False')
is_member()
