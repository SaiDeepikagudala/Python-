# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:21:08 2021

@author: SRINIVAS
"""
def lengths_of_corresp_word(words):
    '''length of each word in list'''
    for word in words:
        print('word:',word,'         length:',len(word))
if __name__ == "__main__":
    words = ['this','is','training','time']
    lengths_of_corresp_word(words)
