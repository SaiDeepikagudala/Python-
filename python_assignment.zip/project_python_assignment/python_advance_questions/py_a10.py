# -*- coding: utf-8 -*-
"""
Created on Thu Apr  1 12:56:08 2021

@author: SRINIVAS
"""

def listOfWords(doc_list,keyword):
    matches = []
    for i in doc_list:
        if keyword in i:
            
            loc = doc_list.index(i)
            matches.append(loc)
    print(matches)
doc_list = ["i am a boy","am cute","good girl","am"]
keyword = 'am'
listOfWords(doc_list,keyword)
