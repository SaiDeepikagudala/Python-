# -*- coding: utf-8 -*-
"""
Created on Thu Apr  1 14:14:55 2021

@author: SRINIVAS
"""

def listOfWords(doc_list,keyword):
    matches = []
    for j in keyword:
        for i in doc_list:
            if j in i:
            
                loc = doc_list.index(i)
                matches.append(loc)
        print(f'[{matches}]')
        matches = []
doc_list = ["i am a boy","am cute","good girl","am","brave girl"]
keyword = ['am','girl']
listOfWords(doc_list,keyword)