# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:21:08 2021

@author: SRINIVAS
"""
def char_freq(input_string):
    '''frequency of characters'''
    dictionary = {}
    print(input_string)
    for i in range(len(input_string)):
        if input_string[i] in dictionary:
            dictionary[input_string[i]]= int(dictionary.get(input_string[i]))+1
        else:
            dictionary[input_string[i]]= 1
    return dictionary
print(char_freq("bdbabdbabbabcbdbabdbdbabababcbcbabbdbbabababcabdb"))
  