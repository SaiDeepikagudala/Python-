# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 22:21:08 2021

@author: SRINIVAS
"""
import string
IGNORED = string.punctuation + " "
def palindrome(str):
    '''checking palindrome'''
    cleanstr = ""
    for i in str :
        cleanstr += "" if i in IGNORED else i
    return cleanstr.lower() == cleanstr[::-1].lower()
print(palindrome("Go hang a salami I'm a lasagna hog."))
print(palindrome("Was it a rat I saw?"))
print(palindrome("Step on no pets"))
print(palindrome("Sit on a potato pan, Otis"))
print(palindrome("Lisa Bonet ate no basil"))
print(palindrome("Satan, oscillate my metallic sonatas"))
print(palindrome("Rise to vote sir"))
print(palindrome("Dammit, I'm mad!"))
print(palindrome("This is not a palindrome"))
